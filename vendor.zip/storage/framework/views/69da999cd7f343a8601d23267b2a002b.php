<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Medical App</title>
    <link rel="shortcut icon" href="<?php echo e(asset('favicon.ico')); ?>" />

    <?php if(app()->isLocal()): ?>
        <?php echo app('Illuminate\Foundation\Vite')->reactRefresh(); ?>
        <?php echo app('Illuminate\Foundation\Vite')('resources/react/src/main.jsx'); ?>
    <?php else: ?>
        <?php
            $manifest = json_decode(file_get_contents(public_path('build/manifest.json')), true);
        ?>
        <link rel="stylesheet" href="<?php echo e(asset('build/' . $manifest['resources/react/src/main.jsx']['css'][0])); ?>">
        <script type="module" src="<?php echo e(asset('build/' . $manifest['resources/react/src/main.jsx']['file'])); ?>"></script>
    <?php endif; ?>
</head>

<body>
    <div id="root"></div>
</body>

</html>
<?php /**PATH D:\Tipic\Project\Medical App\resources\views/welcome.blade.php ENDPATH**/ ?>