// export const host = 'http://localhost:8000' 
export const host = 'https://shardamedical.tipic.co.in' 
