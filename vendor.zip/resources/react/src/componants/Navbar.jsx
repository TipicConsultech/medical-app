import React from 'react'

function Navbar() {
  return (
    <div className='h-10 sticky w-full flex justify-center bg-amber-500'>
      <h1 className='text-2xl text-white'>Sharada Medical</h1>
    </div>
  )
}

export default Navbar
